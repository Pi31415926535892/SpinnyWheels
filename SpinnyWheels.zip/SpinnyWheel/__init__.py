bl_info = {
    "name": "SpinnyWheels - Procedural Caster Animation",
    "author": "Raghav D. Gautam",
    "version": (0, 1),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar",
    "description": "Automatic caster wheel system",
    "category": "Animation",
}

import bpy
from mathutils import Vector
from math import atan2, pi

# ==========================================
# SETTINGS
# ==========================================

timer_running = False


# ==========================================
# UTIL
# ==========================================

def angle_lerp(a, b, t):
    diff = (b - a + pi) % (2 * pi) - pi
    return a + diff * t


# ==========================================
# MAIN UPDATE
# ==========================================

def update_casters():

    scene = bpy.context.scene

    obj = scene.caster_main_object

    if not obj:
        return

    for pivot in obj.children:

        current_pos = pivot.matrix_world.translation.copy()

        if "prev_pos" not in pivot:
            pivot["prev_pos"] = current_pos
            continue

        prev_pos = Vector(pivot["prev_pos"])

        delta = current_pos - prev_pos

        distance = delta.length

        if distance > scene.caster_min_distance:

            direction = delta.normalized()

            local_dir = (
                obj.matrix_world.inverted().to_3x3()
                @ direction
            )

            target_angle = atan2(
                local_dir.y,
                local_dir.x
            ) + 1.5708

            angle_diff = abs(
                target_angle - pivot.rotation_euler.z
            )

            if angle_diff > 0.02:

                pivot.rotation_euler.z = angle_lerp(
                    pivot.rotation_euler.z,
                    target_angle,
                    scene.caster_smoothing
                )

            for wheel in pivot.children:

                rotation_amount = (
                    distance /
                    scene.caster_wheel_radius
                )

                wheel.rotation_euler.x -= rotation_amount

        pivot["prev_pos"] = current_pos

    # redraw viewport
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()


# ==========================================
# TIMER
# ==========================================

def timer_update():

    if bpy.context.scene.caster_enabled:
        update_casters()

    return 0.01


# ==========================================
# UI PANEL
# ==========================================

class CASTER_PT_panel(bpy.types.Panel):

    bl_label = "Procedural Casters"
    bl_idname = "CASTER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Casters'

    def draw(self, context):

        layout = self.layout
        scene = context.scene

        layout.prop(scene, "caster_enabled")
        layout.prop(scene, "caster_main_object")
        layout.prop(scene, "caster_wheel_radius")
        layout.prop(scene, "caster_smoothing")
        layout.prop(scene, "caster_min_distance")


# ==========================================
# REGISTER
# ==========================================

classes = (
    CASTER_PT_panel,
)


def register():

    global timer_running

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.caster_enabled = bpy.props.BoolProperty(
        name="Enabled",
        default=True
    )

    bpy.types.Scene.caster_main_object = bpy.props.PointerProperty(
        name="Main Object",
        type=bpy.types.Object
    )

    bpy.types.Scene.caster_wheel_radius = bpy.props.FloatProperty(
        name="Wheel Radius",
        default=0.15
    )

    bpy.types.Scene.caster_smoothing = bpy.props.FloatProperty(
        name="Smoothing",
        default=0.08
    )

    bpy.types.Scene.caster_min_distance = bpy.props.FloatProperty(
        name="Min Distance",
        default=0.003
    )

    if not timer_running:
        bpy.app.timers.register(timer_update)
        timer_running = True


def unregister():

    global timer_running

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.caster_enabled
    del bpy.types.Scene.caster_main_object
    del bpy.types.Scene.caster_wheel_radius
    del bpy.types.Scene.caster_smoothing
    del bpy.types.Scene.caster_min_distance

    timer_running = False


if __name__ == "__main__":
    register()